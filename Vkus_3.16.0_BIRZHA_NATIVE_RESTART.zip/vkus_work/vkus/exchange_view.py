"""Native Tkinter composition for Vkus Exchange. No screenshot-as-background UI."""
from __future__ import annotations
import tkinter as tk
from tkinter import messagebox
from pathlib import Path

try:
    from PIL import Image, ImageTk, ImageEnhance
except Exception:
    Image = ImageTk = None

W, H = 1672, 941
BG = '#030719'
TEXT = '#edf4ff'
MUTED = '#9aadd3'
PURPLE = '#b62cff'
CYAN = '#14cfff'
GREEN = '#13eaa0'

class ExchangeWindow:
    def __init__(self, parent, on_nav=None):
        self.parent = parent
        self.on_nav = on_nav
        self.win = tk.Toplevel(parent)
        self.win.title('Vkus — Биржа спроса и предложений')
        self.win.geometry('1672x941')
        self.win.minsize(1180, 700)
        self.win.configure(bg=BG)
        self.canvas = tk.Canvas(self.win, bg=BG, highlightthickness=0, bd=0)
        self.canvas.pack(fill='both', expand=True)
        self.sources = {'VK': False, 'Telegram': False, 'Avito': True, 'YouDo': False, 'Профи.ру': False, 'Форумы': False}
        self.filters = {'Город': 'Оренбург', 'Радиус': '50 км', 'Период': 'За всё время', 'Категория': 'Все категории'}
        self.placeholder = 'Например: ремонт компьютера, настройка рекламы, доставка...'
        self.query = tk.StringVar(value='')
        self._panel_photos = []
        self._panel_cache = {}
        self._text_photos = []
        self.entry = tk.Entry(self.win, textvariable=self.query, bg='#0b1736', fg='#a7b8dc',
                              insertbackground='white', relief='flat', bd=0,
                              font=('DejaVu Sans', 15), highlightthickness=1,
                              highlightbackground='#314d91', highlightcolor='#21cfff')
        self.entry.insert(0, self.placeholder)
        self.entry.bind('<FocusIn>', self._focus_in)
        self.entry.bind('<FocusOut>', self._focus_out)
        self.entry.bind('<Return>', lambda _e: self._search_notice())
        self.canvas.bind('<Configure>', self._redraw)
        self.canvas.bind('<Button-1>', self._click)
        self.win.protocol('WM_DELETE_WINDOW', self.close)
        self._redraw()

    def close(self):
        try: self.win.destroy()
        except tk.TclError: pass

    def _focus_in(self, _=None):
        if self.entry.get() == self.placeholder:
            self.entry.delete(0, 'end'); self.entry.configure(fg=TEXT)

    def _focus_out(self, _=None):
        if not self.entry.get().strip():
            self.entry.insert(0, self.placeholder); self.entry.configure(fg='#a7b8dc')

    def _round(self, x1,y1,x2,y2,r=18,fill='#0a1430',outline='#263b78',width=1,tags=None):
        # Smooth native canvas polygon, not a raster screenshot.
        pts=[x1+r,y1,x2-r,y1,x2,y1,x2,y1+r,x2,y2-r,x2,y2,x2-r,y2,x1+r,y2,x1,y2,x1,y2-r,x1,y1+r,x1,y1]
        pts=[self.ox+v*self.scale if i%2==0 else self.oy+v*self.scale for i,v in enumerate(pts)]
        self.canvas.create_polygon(pts, smooth=True, splinesteps=18, fill=fill, outline=outline, width=max(1,width*self.scale), tags=tags)

    def _text(self,x,y,s,size=14,color=TEXT,bold=False,anchor='nw',tags=None):
        self.canvas.create_text(self.ox+x*self.scale,self.oy+y*self.scale,text=s,fill=color,font=('DejaVu Sans',max(7,int(size*self.scale)),'bold' if bold else 'normal'),anchor=anchor,tags=tags)

    def _draw_kpi_icon(self,kind,x,y,color):
        c=self.canvas; s=self.scale
        def X(v): return self.ox+v*s
        def Y(v): return self.oy+v*s
        lw=max(2,int(2.4*s))
        if kind=='person':
            c.create_oval(X(x+8),Y(y),X(x+25),Y(y+17),outline=color,width=lw)
            c.create_arc(X(x+2),Y(y+15),X(x+32),Y(y+43),start=0,extent=180,style='arc',outline=color,width=lw)
            c.create_oval(X(x+25),Y(y+23),X(x+39),Y(y+37),outline=color,width=lw)
            c.create_line(X(x+36),Y(y+35),X(x+43),Y(y+42),fill=color,width=lw)
        elif kind=='case':
            c.create_rectangle(X(x+2),Y(y+12),X(x+40),Y(y+39),outline=color,width=lw)
            c.create_line(X(x+13),Y(y+12),X(x+13),Y(y+6),X(x+29),Y(y+6),X(x+29),Y(y+12),fill=color,width=lw)
            c.create_line(X(x+2),Y(y+23),X(x+40),Y(y+23),fill=color,width=lw)
            c.create_rectangle(X(x+18),Y(y+20),X(x+24),Y(y+26),fill=color,outline=color)
        elif kind=='target':
            for r in (19,12,5): c.create_oval(X(x+21-r),Y(y+21-r),X(x+21+r),Y(y+21+r),outline=color,width=lw)
            c.create_line(X(x+20),Y(y+22),X(x+38),Y(y+4),fill=color,width=lw)
            c.create_line(X(x+31),Y(y+4),X(x+38),Y(y+4),X(x+38),Y(y+11),fill=color,width=lw)
        elif kind=='bars':
            for bx,by,bh in ((2,22,18),(15,12,28),(28,3,37)):
                c.create_rectangle(X(x+bx),Y(y+by),X(x+bx+9),Y(y+by+bh),outline=color,fill=color,width=1)
        elif kind=='star':
            pts=[]
            import math
            for i in range(10):
                a=-math.pi/2+i*math.pi/5; r=21 if i%2==0 else 9
                pts.extend([X(x+22+math.cos(a)*r),Y(y+22+math.sin(a)*r)])
            c.create_polygon(pts,outline=color,fill='',width=lw)

    def _gradient_text(self,x,y,text,size,left='#d65cff',right='#25bfff',anchor='nw'):
        if Image is None or ImageTk is None:
            self._text(x,y,text,size,left,True,anchor); return
        from PIL import ImageDraw, ImageFont
        px=max(8,int(size*self.scale))
        font_path='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
        font=ImageFont.truetype(font_path,px)
        bbox=font.getbbox(text); tw=max(1,bbox[2]-bbox[0]); th=max(1,bbox[3]-bbox[1])
        mask=Image.new('L',(tw+4,th+4),0); md=ImageDraw.Draw(mask)
        md.text((2-bbox[0],2-bbox[1]),text,font=font,fill=255)
        a=tuple(int(left[i:i+2],16) for i in (1,3,5)); b=tuple(int(right[i:i+2],16) for i in (1,3,5))
        grad=Image.new('RGBA',mask.size,(0,0,0,0)); pix=grad.load()
        for xx in range(grad.width):
            t=xx/max(1,grad.width-1); col=tuple(int(a[k]*(1-t)+b[k]*t) for k in range(3))
            for yy in range(grad.height): pix[xx,yy]=(*col,mask.getpixel((xx,yy)))
        photo=ImageTk.PhotoImage(grad); self._text_photos.append(photo)
        ax=self.ox+x*self.scale; ay=self.oy+y*self.scale
        if anchor in ('n','center'): ax-=grad.width/2
        if anchor in ('center','e'): ay-=grad.height/2
        self.canvas.create_image(ax,ay,image=photo,anchor='nw')

    def _gradient_button(self,box):
        x1,y1,x2,y2=box; s=self.scale
        if Image is None or ImageTk is None: return
        from PIL import ImageDraw, ImageFilter
        w=max(4,int((x2-x1)*s)); h=max(4,int((y2-y1)*s)); key=('button',w,h)
        photo=self._panel_cache.get(key)
        if photo is None:
            glow=Image.new('RGBA',(w+20,h+20),(0,0,0,0)); gd=ImageDraw.Draw(glow)
            gd.rounded_rectangle((8,8,w+11,h+11),radius=max(5,int(12*s)),outline=(161,52,255,220),width=max(2,int(3*s)))
            glow=glow.filter(ImageFilter.GaussianBlur(max(2,int(7*s))))
            im=Image.new('RGBA',(w+20,h+20),(0,0,0,0)); im.alpha_composite(glow); d=ImageDraw.Draw(im)
            c1=(163,23,245); c2=(29,75,255)
            for xx in range(w):
                t=xx/max(1,w-1); col=tuple(int(c1[k]*(1-t)+c2[k]*t) for k in range(3))+(255,)
                d.line((10+xx,10,10+xx,h+9),fill=col)
            d.rounded_rectangle((9,9,w+10,h+10),radius=max(5,int(12*s)),outline=(197,87,255,255),width=max(1,int(s)))
            photo=ImageTk.PhotoImage(im); self._panel_cache[key]=photo
        self.canvas.create_image(self.ox+(x1-10/s)*s,self.oy+(y1-10/s)*s,image=photo,anchor='nw')

    def _panel(self, box, accent='purple', fill='#08132d', radius=18):
        x1,y1,x2,y2=box
        # A reusable, softly illuminated panel skin; text and controls remain native Canvas/Tk widgets.
        if Image is not None and ImageTk is not None:
            from PIL import ImageDraw, ImageFilter
            s=max(.5,self.scale); w=max(4,int((x2-x1)*s)); h=max(4,int((y2-y1)*s)); key=(w,h,accent,fill,radius)
            photo=self._panel_cache.get(key)
            if photo is None:
                rgb={'purple':(132,43,255),'cyan':(18,168,255),'green':(17,216,169),'gold':(238,167,43)}.get(accent,(132,43,255))
                glow=Image.new('RGBA',(w+24,h+24),(0,0,0,0)); gd=ImageDraw.Draw(glow)
                gd.rounded_rectangle((10,10,w+13,h+13),radius=max(5,int(radius*s)),outline=(*rgb,175),width=max(2,int(3*s)))
                glow=glow.filter(ImageFilter.GaussianBlur(max(2,int(8*s))))
                base=Image.new('RGBA',(w+24,h+24),(0,0,0,0)); base.alpha_composite(glow)
                draw=ImageDraw.Draw(base)
                top=(10,17,42); bot=(5,13,31)
                for yy in range(h):
                    t=yy/max(1,h-1); col=tuple(int(top[i]*(1-t)+bot[i]*t) for i in range(3))+(255,)
                    draw.line((12,12+yy,w+11,12+yy),fill=col)
                draw.rounded_rectangle((11,11,w+12,h+12),radius=max(5,int(radius*s)),outline=(*rgb,230),width=max(1,int(s)))
                photo=ImageTk.PhotoImage(base); self._panel_cache[key]=photo
            self._panel_photos.append(photo)
            self.canvas.create_image(self.ox+(x1-12/s)*s,self.oy+(y1-12/s)*s,image=photo,anchor='nw')
        else:
            glow = {'purple':'#8f2dff','cyan':'#087dc0','green':'#087c78','gold':'#8d5b18'}.get(accent,'#8f2dff')
            self._round(x1,y1,x2,y2,radius,fill=fill,outline=glow,width=1)

    def _redraw(self, _=None):
        c=self.canvas; c.delete('all'); self._text_photos=[]
        ww=max(1,c.winfo_width()); hh=max(1,c.winfo_height())
        self.scale=min(ww/W,hh/H); self.ox=(ww-W*self.scale)/2; self.oy=(hh-H*self.scale)/2
        c.create_rectangle(0,0,ww,hh,fill='#020615',outline='')
        c.create_rectangle(self.ox,self.oy,self.ox+W*self.scale,self.oy+H*self.scale,fill='#03091d',outline='')
        c.create_rectangle(self.ox,self.oy,self.ox+W*self.scale,self.oy+H*self.scale,outline='#6422aa',width=2)
        c.create_rectangle(self.ox+270*self.scale,self.oy+2*self.scale,self.ox+W*self.scale,self.oy+H*self.scale,outline='#173a82',width=1)
        # Subtle atmospheric light, drawn independently of the content.
        for i in range(7):
            x=720+i*145
            c.create_line(self.ox+x*self.scale,self.oy+8*self.scale,self.ox+(x-120)*self.scale,self.oy+350*self.scale,fill='#10265a',width=max(1,int(2*self.scale)))
        c.create_oval(self.ox+760*self.scale,self.oy-130*self.scale,self.ox+1450*self.scale,self.oy+480*self.scale,outline='#0a2450',width=max(1,int(2*self.scale)))
        # Sidebar shell
        self._panel((12,14,267,927),'purple','#050a20',22)
        self._text(138,30,'♛',36,'#c64cff',True,'n')
        self._gradient_text(138,72,'Vkus',44,'#8f55ff','#1bbfff','n')
        self._text(138,139,'ПОИСК СПРОСА  •  ВОЗМОЖНОСТИ',7,'#7897d4',True,'n')
        # Crop only the brand animal from the supplied reference; no screen/UI is reused.
        if Image is not None and ImageTk is not None:
            try:
                if not hasattr(self,'tiger_photo'):
                    crop=Image.open(Path(__file__).resolve().parent/'assets'/'birzha_tiger.png').convert('RGBA').resize((220,188),Image.Resampling.LANCZOS)
                    self.tiger_photo=ImageTk.PhotoImage(crop)
                c.create_image(self.ox+139*self.scale,self.oy+273*self.scale,image=self.tiger_photo,anchor='center')
            except Exception: pass
        nav=[('☏','Сообщения',''),('⌕','Поиск',''),('⇄','Биржа','active'),('▥','Мониторинг',''),('⚙','Настройки','')]
        for i,(ic,label,state) in enumerate(nav):
            y=382+i*61
            if state=='active':
                self._round(12,y,253,y+55,13,'#16105b','#8e29ff',1)
                c.create_line(self.ox+14*self.scale,self.oy+(y+6)*self.scale,self.ox+14*self.scale,self.oy+(y+48)*self.scale,fill='#ed36ff',width=max(2,int(3*self.scale)))
            self._text(36,y+10,ic,25,'#c13dff' if state!='active' else '#32dfff',True)
            self._text(90,y+17,label,15,TEXT if state=='active' else '#a6bce8',state=='active')
        self._panel((28,728,250,855),'cyan','#06142d',16)
        self._text(46,746,'Ваш статус',12,'#b7c9e9')
        self._text(46,775,'●  Локальный режим',12,GREEN,True)
        self._text(46,811,'Источники',11,'#d5e2fb',True)
        self._text(46,835,'ещё не подключены',9,'#849bc7')
        self._text(35,887,'Vkus  •  Биржа',10,'#7b8db8')
        # Header
        self._gradient_text(305,40,'Биржа спроса и предложений',42,'#d85bff','#26bfff','nw')
        self._text(307,99,'Находите клиентов, исполнителей и актуальные задачи рядом с вами',17,'#d6e2ff')
        self._text(1490,88,'Спрос есть.',17,'#bf5cff',True,'n')
        self._text(1490,112,'Найдём вместе!',17,'#bf5cff',True,'n')
        self._text(1320,30,'● Локально',11,GREEN,True)
        # KPI cards: intentionally no invented metrics.
        cards=[(301,171,543,346,'purple','person','Заявки','—','Найденные потребности'),(561,171,808,346,'cyan','case','Специалисты','—','Предложения услуг'),(827,171,1074,346,'purple','target','Новые задачи','—','Разовые задания'),(1093,171,1340,346,'green','bars','Анализ спроса','—','После подключения источников'),(1359,171,1616,346,'gold','star','Релевантность','—','Оценка результатов')]
        for x1,y1,x2,y2,ac,ic,title,val,sub in cards:
            self._panel((x1,y1,x2,y2),ac,'#09152f',18)
            icon_color={'purple':'#c14dff','cyan':'#10cfff','green':'#19e5b3','gold':'#ffc64b'}[ac]
            self._draw_kpi_icon(ic,x1+25,y1+20,icon_color)
            self._text(x1+90,y1+26,title,13 if title=='Специалисты' else 14,TEXT,True)
            self._text(x1+90,y1+68,val,29,'#eaf2ff',True)
            self._text((x1+x2)//2,y1+135,sub,10,'#9aadd3','', 'n')
        # Search panel
        self._panel((301,374,1342,557),'cyan','#08152f',19)
        self._text(326,390,'⌕',34,CYAN,True)
        self._text(372,399,'Умный поиск',22,TEXT,True)
        self._text(1105,404,'Расширенный поиск  ⌄',11,'#299cff',True)
        self._round(320,435,1164,489,13,'#0b1837','#405b9b',1)
        self._text(324,507,'⌖  '+self.filters['Город']+'  ▾',12,TEXT)
        self._text(492,507,'◉  Радиус: '+self.filters['Радиус']+'  ▾',12,TEXT)
        self._text(705,507,'▦  '+self.filters['Период']+'  ▾',12,TEXT)
        self._text(913,507,'▦  '+self.filters['Категория']+'  ▾',12,TEXT)
        self._gradient_button((1178,435,1325,489))
        self._text(1251,462,'⌕  Найти',15,'#ffffff',True,'center')
        # Source tiles with individual brand-like marks.
        self._text(303,572,'◎  Источники поиска',16,TEXT,True)
        names=['VK','Telegram','Avito','YouDo','Профи.ру','Форумы']
        sx=[301,445,589,733,877,1021]
        for name,x in zip(names,sx):
            selected=self.sources[name]
            self._panel((x,610,x+132,691),'purple' if selected else 'cyan' if name in ('VK','Telegram') else 'purple','#0a1530',15)
            if selected: self._round(x+3,612,x+129,689,14,'#0a1530','#e04aff',2)
            if name=='VK': self._text(x+66,628,'vk',25,'#20b9ff',True,'n')
            elif name=='Telegram': self._text(x+66,628,'➤',25,'#24caff',True,'n')
            elif name=='Avito':
                for dx,dy,col in [(-10,-4,'#f43a7b'),(0,-4,'#22c7ff'),(10,-4,'#ffcf38'),(-5,7,'#9a43ff'),(6,7,'#16d9a0')]: c.create_oval(self.ox+(x+66+dx-5)*self.scale,self.oy+(637+dy-5)*self.scale,self.ox+(x+66+dx+5)*self.scale,self.oy+(637+dy+5)*self.scale,fill=col,outline='')
            elif name=='YouDo': self._text(x+66,628,'Y.',27,'#ffffff',True,'n')
            elif name=='Профи.ру': self._text(x+66,628,'P',27,'#ff426c',True,'n')
            else:
                c.create_oval(self.ox+(x+43)*self.scale,self.oy+624*self.scale,self.ox+(x+84)*self.scale,self.oy+652*self.scale,outline='#26caff',width=max(2,int(2*self.scale)))
                c.create_line(self.ox+(x+54)*self.scale,self.oy+650*self.scale,self.ox+(x+49)*self.scale,self.oy+658*self.scale,self.ox+(x+63)*self.scale,self.oy+652*self.scale,fill='#26caff',width=max(2,int(2*self.scale)))
                c.create_oval(self.ox+(x+58)*self.scale,self.oy+633*self.scale,self.ox+(x+62)*self.scale,self.oy+637*self.scale,fill='#26caff',outline='')
                c.create_oval(self.ox+(x+67)*self.scale,self.oy+633*self.scale,self.ox+(x+71)*self.scale,self.oy+637*self.scale,fill='#26caff',outline='')
            self._text(x+66,666,name,13,TEXT,True,'center')
        self._panel((1165,610,1342,691),'purple','#0a1530',15)
        self._text(1253,630,'＋',26,'#9bc8ff',True,'n'); self._text(1253,667,'Ещё 5',13,TEXT,True,'center')
        # Right explainer panel
        self._panel((1360,374,1618,691),'purple','#09142d',18)
        self._text(1380,392,'▥  Что можно найти?',13,TEXT,True)
        bullets=['Заявки на услуги\nи ремонт','Разовые задачи\nи подработка','Вакансии и работа','Товары и предложения','Потребность в помощи']
        for i,t in enumerate(bullets):
            y=433+i*45; self._text(1382,y,'✓',16,GREEN,True); self._text(1410,y+1,t,10,'#d4e0fb')
        self._round(1372,633,1605,679,12,'#24105a','#9e35ff',1)
        self._text(1387,647,'ϟ',25,'#d65bff',True)
        self._text(1425,642,'Vkus анализирует спрос',8,'#e2b2ff',True)
        self._text(1425,658,'после подключения источников',5,'#b9a4e6')
        # Lower panels: honest empty states, not demo leads/city counts.
        self._panel((301,716,857,895),'purple','#08142e',18)
        self._text(322,734,'◉  Последние находки',15,TEXT,True)
        self._text(829,738,'Пока нет данных',9,'#93a9d1',False,'ne')
        self._text(579,808,'Подключите источники, чтобы увидеть',12,'#9db2d8',False,'center')
        self._text(579,832,'реальные заявки и предложения',12,'#9db2d8',False,'center')
        self._panel((872,716,1332,895),'cyan','#08142e',18)
        self._text(895,734,'⌖  Регионы и активность',15,TEXT,True)
        # Standalone map illustration cropped from the visual reference; no live activity count is implied.
        if Image is not None and ImageTk is not None:
            try:
                target=(max(1,int(270*self.scale)),max(1,int(108*self.scale)))
                if not hasattr(self,'map_photo') or getattr(self,'map_photo_size',None)!=target:
                    mp=Image.open(Path(__file__).resolve().parent/'assets'/'birzha_map_russia.png').convert('RGBA').resize(target,Image.Resampling.LANCZOS)
                    self.map_photo=ImageTk.PhotoImage(mp); self.map_photo_size=target
                c.create_image(self.ox+900*self.scale,self.oy+770*self.scale,image=self.map_photo,anchor='nw')
            except Exception: pass
        self._text(1175,792,'География',16,'#dfeaff',True)
        self._text(1175,821,'появится после',9,'#9fb4dc')
        self._text(1175,840,'сбора данных',9,'#9fb4dc')
        self._panel((1347,716,1618,895),'purple','#08142e',18)
        self._text(1368,734,'▥  Опции анализа',14,TEXT,True)
        for i,t in enumerate(['Определение намерения','Подбор ниши','Оценка спроса','Уведомления о заявках']):
            self._text(1370,775+i*25,'✓',13,GREEN,True); self._text(1392,777+i*25,t,9,'#c9d8f5')
        self._text(1482,876,'Настроить',10,'#bd85ff',True,'center')
        # Resize native query field in same coordinate system.
        s=self.scale
        self.entry.place(x=self.ox+320*s,y=self.oy+437*s,width=842*s,height=50*s)
        self.entry.configure(font=('DejaVu Sans',max(9,int(15*s))))

    def _click(self,event):
        x=(event.x-self.ox)/self.scale; y=(event.y-self.oy)/self.scale
        if 1170<=x<=1335 and 430<=y<=495: self._search_notice(); return
        if 295<=x<=1345 and 600<=y<=700:
            names=['VK','Telegram','Avito','YouDo','Профи.ру','Форумы']; starts=[301,445,589,733,877,1021]
            for name,x1 in zip(names,starts):
                if x1<=x<=x1+132 and 608<=y<=693:
                    self.sources[name]=not self.sources[name]; self._redraw(); return
        if 1160<=x<=1350 and 600<=y<=700:
            messagebox.showinfo('Vkus — источники','Дополнительные источники будут оформлены после утверждения визуала.',parent=self.win); return
        filters=[('Город',['Оренбург','Орск','Москва','Санкт-Петербург','Екатеринбург']),('Радиус',['10 км','25 км','50 км','100 км','Вся страна']),('Период',['За сутки','За 7 дней','За 30 дней','За 3 месяца','За всё время']),('Категория',['Все категории','Услуги и ремонт','Работа и вакансии','Покупка и продажа','Разовые задачи','Помощь и специалисты'])]
        areas=[(310,495,475,550),(480,495,690,550),(695,495,895,550),(900,495,1115,550)]
        for (title,opts),(x1,y1,x2,y2) in zip(filters,areas):
            if x1<=x<=x2 and y1<=y<=y2:
                menu=tk.Menu(self.win,tearoff=0,bg='#0b1532',fg=TEXT,activebackground='#5120a2',activeforeground='white')
                for val in opts: menu.add_command(label=val,command=lambda t=title,v=val:self._set_filter(t,v))
                menu.tk_popup(event.x_root,event.y_root); menu.grab_release(); return
        if 10<=x<=265 and 370<=y<=700:
            if self.on_nav:
                if y<445: self.on_nav('Сообщения')
                elif y<505: self.on_nav('Поиск')
                elif y<565: return
                elif y<625: self.on_nav('Мониторинг')
                else: self.on_nav('Настройки')

    def _set_filter(self,title,value):
        self.filters[title]=value; self._redraw()

    def _search_notice(self):
        q=self.query.get().strip()
        if q==self.placeholder: q=''
        messagebox.showinfo('Vkus — Биржа','Визуальный этап. Реальный поиск и коннекторы будут подключаться только после утверждения интерфейса.',parent=self.win)
