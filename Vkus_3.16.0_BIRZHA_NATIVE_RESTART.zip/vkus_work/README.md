# Vkus — clean Birzha visual rebuild (3.16.0)

Изменения:
- поиск сообществ использует реальный маршрут VK: `https://vk.ru/search/communities?q=...`;
- старый `search?c[q]=...&c[section]=communities` удалён из основного маршрута;
- Vkus больше не пытается вручную переключать вкладку «Сообщества» после открытия общего поиска;
- ожидание результатов сообщества увеличено, а при отсутствии выдачи в ошибке показывается фактический адрес, который открыл Firefox;
- исправлена обработка комментариев по прямой ссылке на сообщество: отсутствие машинной даты больше не отбрасывает комментарий, если месяц/год не заданы;
- стартовое видео: `assets/vkus_start.mp4`, окно заставки — 8 секунд.


## Вкладка «Биржа» (UI)

Добавлена отдельная вкладка «Биржа» в боковую навигацию. В интерфейсе есть переключение между заявками, специалистами и собственными публикациями; фильтры по запросу, региону, городу и направлению; выбор источников VK, Telegram, Avito, YouDo, Профи.ру и форумов.

Важно: в этой версии реализован интерфейс. Коннекторы внешних площадок, сбор реальных публикаций, классификация намерений и создание публикаций ещё не подключены. Вкладка явно показывает это состояние и не выдаёт демонстрационные записи за реальные результаты.

## Birzha visual rebuild — clean restart

The previous screenshot-backed Birzha implementation has been removed. The current screen is composed from native Tkinter Canvas primitives and widgets in `vkus/exchange_view.py`; the approved PNG is retained only under `design/reference/` for visual comparison. The tiger crop is a standalone brand asset (`vkus/assets/birzha_tiger.png`).

This phase is visual-only. Search adapters, marketplace storage, matching, and source integrations are intentionally not connected. KPI values and live-found items are not fabricated; the interface displays empty states until data sources are implemented.
